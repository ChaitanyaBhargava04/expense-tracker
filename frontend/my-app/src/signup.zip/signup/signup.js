// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
// import {faCoffee} from "@fortawesome/free-solid-svg-icons";
import './signup.css';
import image4 from '../signup/8432.jpg';
function Signup() {
    return (
      <div className="signup">
        <div class="row">
        <div class="col-6">
        <div class="form">
        <p class="p"> Hello,Friend</p>
        <form>
        <input type="text" class="text1" placeholder="Name" name="uname" required ></input>
        <input type="text" class="text2" placeholder="Example@gmail.com" name="email" required></input>
        <input type="password" class="text3" placeholder="Password" name="psw" required></input>
        </form>
        <h6>OR</h6>
        <h6>Sign-up with</h6>
        <a href=""><span class="dot1"></span></a>
        <a href=""><span class="dot2"></span></a>
        <a href=""><span class="dot3"></span></a>
        <a href=""><span class="dot4"></span></a>
        <a href=""><span class="dot5"></span></a>
        <input type="checkbox" class="check1"></input>
        <span id="span2">I read and agree to</span>
        <span id="span1">Terms & Conditions</span>
        <button class="button1">CREATE ACCOUNT</button>
        </div>
        </div>
        <div class="col-6">
        <p class="p2"> Managing money, made simple</p>
        <img src={image4} width="400px" height="400px"/>
        </div>
        </div>
        </div>
        );
        }
        
        export default Signup;